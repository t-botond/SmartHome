/**
 * Betöltjük azösszes eszközt az adatbázisból
 * Az eredményt mentjük a res.locals.dev-be
 */

module.exports = function (objectrepository) {
    return function (req, res, next) {

        next();
    };
};