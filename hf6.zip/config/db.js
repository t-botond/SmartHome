const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/SR9IVY');
module.exports=mongoose;

